package streaming;
import java.util.ArrayList;
/* *********** Pledge of Honor ************************************************ *

I hereby certify that I have completed this lab assignment on my own
without any help from anyone else. I understand that the only sources of authorized
information in this lab assignment are (1) the course textbook, (2) the
materials posted at the course website and (3) any study notes handwritten by myself.
I have not used, accessed or received any information from any other unauthorized
source in taking this lab assignment. The effort in the assignment thus belongs
completely to me.
READ AND SIGN BY WRITING YOUR NAME SURNAME AND STUDENT ID
SIGNATURE: Ece Nur Karahan , 80029
********************************************************************************/
import devices.Device;
import media.Genre;
public class User{
	protected String name;
	protected ArrayList<Genre> likedGenres;
	protected ArrayList<Device> devices;
	protected Device currentDevice;
	public User(String name) {
		this.name = name;
		this.likedGenres = new ArrayList<Genre>(100);
		this.devices =  new ArrayList<Device>(100);
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public ArrayList<Genre> getLikedGenres() {
		return likedGenres;
	}
	public void setLikedGenres(ArrayList<Genre> likedGenres) {
		this.likedGenres = likedGenres;
	}
	public ArrayList<Device> getDevices() {
		return devices;
	}
	public void setDevices(ArrayList<Device> devices) {
		this.devices = devices;
	}
	public void likeGenre(Genre g) {
		this.likedGenres.add(g);
		this.setLikedGenres(likedGenres);
	}
	public void unlikeGenre(Genre g) {
		if(this.likedGenres.contains(g)) {
			this.likedGenres.remove(g);
		}
	}
	public void removeDevice(Device d) {
		if(this.devices.contains(d)) {
			this.devices.remove(d);
		}
	}
	public String postNotificationText(int notCount) {
		return "Download KuVPN now and get 10% off your next subscription.";
	}
	
}
