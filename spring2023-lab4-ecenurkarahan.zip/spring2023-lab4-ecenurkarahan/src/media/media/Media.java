package media;
import media.Genre;
/* *********** Pledge of Honor ************************************************ *

I hereby certify that I have completed this lab assignment on my own
without any help from anyone else. I understand that the only sources of authorized
information in this lab assignment are (1) the course textbook, (2) the
materials posted at the course website and (3) any study notes handwritten by myself.
I have not used, accessed or received any information from any other unauthorized
source in taking this lab assignment. The effort in the assignment thus belongs
completely to me.
READ AND SIGN BY WRITING YOUR NAME SURNAME AND STUDENT ID
SIGNATURE: Ece Nur Karahan , 80029
********************************************************************************/
public class Media{
	protected String name;
	protected int publishYear;
	public Genre genre;
	public Media(String name, int publishYear, Genre genre) {
		this.name = name;
		this.publishYear = publishYear;
		this.genre = genre;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPublishYear() {
		return publishYear;
	}
	public void setPublishYear(int publishYear) {
		this.publishYear = publishYear;
	}
	public Genre getGenre() {
		return genre;
	}
	public void setGenre(Genre genre) {
		this.genre = genre;
	}
	@Override
	public String toString() {
		return "Name: " + name +"\n"+"Year: " + publishYear + "\n"+"Genre: " + genre + "\n";
	}
	public String generateNotification() {
		String welcome = "We tought you might like it!"+"\n";
		String lines= "--------------------------------------------------\n";
		return welcome+lines;
	}
	
	
}