package media;
import media.Genre;
/* *********** Pledge of Honor ************************************************ *

I hereby certify that I have completed this lab assignment on my own
without any help from anyone else. I understand that the only sources of authorized
information in this lab assignment are (1) the course textbook, (2) the
materials posted at the course website and (3) any study notes handwritten by myself.
I have not used, accessed or received any information from any other unauthorized
source in taking this lab assignment. The effort in the assignment thus belongs
completely to me.
READ AND SIGN BY WRITING YOUR NAME SURNAME AND STUDENT ID
SIGNATURE: Ece Nur Karahan , 80029
********************************************************************************/
public class Movie extends Media{
	protected String director;
	protected int durHour;
	protected int durMin;
	public Movie(String name,int publishYear,Genre genre,String director, int durHour, int durMin) {
		
		super( name,publishYear, genre);
		this.director= director;
		this.durHour = durHour;
		this.durMin = durMin;
		
	}
	public String toString() {
		String info="Movie Information:"+"\n";
		String inheritedstr =super.toString();
		String extension = "Director: "+this.director+"\n"+"Duration: "+ this.durHour+" hours and "+this.durMin+" minutes"+"\n";
		return info+ inheritedstr+ extension;
		
	}
	public String generateNotification() {
		String genresentence= "A new "+this.genre+ " movie is added to our platform."+ "\n";
		return genresentence + super.generateNotification();
	}
}