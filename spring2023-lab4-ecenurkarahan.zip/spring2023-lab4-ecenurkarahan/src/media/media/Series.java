package media;
/* *********** Pledge of Honor ************************************************ *

I hereby certify that I have completed this lab assignment on my own
without any help from anyone else. I understand that the only sources of authorized
information in this lab assignment are (1) the course textbook, (2) the
materials posted at the course website and (3) any study notes handwritten by myself.
I have not used, accessed or received any information from any other unauthorized
source in taking this lab assignment. The effort in the assignment thus belongs
completely to me.
READ AND SIGN BY WRITING YOUR NAME SURNAME AND STUDENT ID
SIGNATURE: Ece Nur Karahan , 80029
********************************************************************************/
public class Series extends Media {
	protected String nameNet;
	protected int durSeason;
	protected int episodes;
	
	public Series(String name,int publishYear,Genre genre,String nameNet, int durSeason, int episodes){
		super(name,publishYear, genre);
		this.nameNet= nameNet;
		this.durSeason = durSeason;
		this.episodes = episodes;
	}
	public String toString() {
		String info= "Series Information:"+"\n";
		String addition = "Network: \r\n"+this.nameNet+ "\r\n"+"Duration: "+this.durSeason+" seasons and "+this.episodes+" episodes\r\n";
		return info + super.toString()+ addition;
	}
	public String generateNotification() {
		String genresentence= "A new "+this.genre+ " series is added to our platform."+ "\n";
		return genresentence + super.generateNotification();
	}
}