package streaming;
import devices.Device;
public class PremiumUser extends User {

	public PremiumUser(String name) {
		super(name);
	}

	@Override
	public String postNotificationText(int notCount) {
		// TODO Auto-generated method stub
		String preStr = "You have "+ notCount + " notification.";
		return preStr;
	}
	
}
