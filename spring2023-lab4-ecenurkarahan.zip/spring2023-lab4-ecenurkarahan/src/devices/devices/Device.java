package devices;
import java.util.ArrayList;
/* *********** Pledge of Honor ************************************************ *

I hereby certify that I have completed this lab assignment on my own
without any help from anyone else. I understand that the only sources of authorized
information in this lab assignment are (1) the course textbook, (2) the
materials posted at the course website and (3) any study notes handwritten by myself.
I have not used, accessed or received any information from any other unauthorized
source in taking this lab assignment. The effort in the assignment thus belongs
completely to me.
READ AND SIGN BY WRITING YOUR NAME SURNAME AND STUDENT ID
SIGNATURE: Ece Nur Karahan , 80029
********************************************************************************/
import media.Media;
import streaming.User;
public class Device{
	protected static int devId=0;
	protected int id;
	protected User user;
	protected  int notCount =0;
	public Device(User user) {
		this.user= user;
		devId++;
		this.id= devId;
		this.user.getDevices().add(this);
		ArrayList<Device> devices = this.user.getDevices() ;
		this.user.setDevices(devices);
	}
	public String notifyOwner(Media m) {
		String hey = "Hey there "+ this.user.getName()+",\n";
		String intro = m.generateNotification()+"\n";
		String lines= "--------------------------------------------------\n";
		String info = m.toString();
		notCount += 1;
		return lines+hey+intro+info+lines;
	}
	public int getId() {
		return this.id-1;
	}
}