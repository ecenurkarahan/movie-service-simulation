package streaming;

public class FreeUser extends User {
	public FreeUser(String name) {
		super(name);
	}

	@Override
	public String postNotificationText(int notCount) {
		// TODO Auto-generated method stub
		return super.postNotificationText(notCount);
	}
	

}
