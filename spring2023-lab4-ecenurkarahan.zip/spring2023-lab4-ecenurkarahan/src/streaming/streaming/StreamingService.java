package streaming;

import java.util.ArrayList;
/* *********** Pledge of Honor ************************************************ *

I hereby certify that I have completed this lab assignment on my own
without any help from anyone else. I understand that the only sources of authorized
information in this lab assignment are (1) the course textbook, (2) the
materials posted at the course website and (3) any study notes handwritten by myself.
I have not used, accessed or received any information from any other unauthorized
source in taking this lab assignment. The effort in the assignment thus belongs
completely to me.
READ AND SIGN BY WRITING YOUR NAME SURNAME AND STUDENT ID
SIGNATURE: Ece Nur Karahan , 80029
********************************************************************************/
import devices.Device;
import media.Genre;
import media.Media;

public class StreamingService{

protected ArrayList<Media> media;
protected ArrayList<User> users;
	public StreamingService() {
		this.media=  new ArrayList<Media>(200);
		this.users = new ArrayList<User>(1000);
	}
	public void addMedia(Media m) {
		for(int i=0;i<this.media.size();i++) {
			String mediaName= this.media.get(i).getName();
			if( mediaName == m.getName()) {
			System.out.println("Media with the same name already exists. Media cannot be added to StreamingService");
			return;
		}
		}
			this.media.add(m);
			System.out.println("Media added to the Streaming Service");
	}
	
	public void addUser(User u) {
		for(int i=0;i<this.users.size();i++) {
			String userName= this.users.get(i).getName();
			if( userName == u.getName()) {
			System.out.println("User with the same name already exists. User cannot be added to StreamingService");
			return;
		}
		}
			this.users.add(u);
			System.out.println("User added to the Streaming Service");
	}
	public void notifyAllUsers() {
		for(int i =0; i<users.size();i++) {
			User user= users.get(i);
			ArrayList<Genre> likedGenres = user.getLikedGenres();
			ArrayList<Device> devices = user.getDevices();
			for(int j=0; j<this.media.size(); j++) {
				Media media = this.media.get(j);
				for(int k =0 ; k< likedGenres.size();k++) {
					if(media.getGenre()==likedGenres.get(k)) {
						for(int e =0; e< devices.size();e++) {
							Device device= devices.get(e);
							System.out.println(device.notifyOwner(media));
						}
					}
				}
			}
		}
	}
}